# web-application-counter
A Sample web application for creating counter with the help of EKS,terraform,MongoDB,NodeJS
